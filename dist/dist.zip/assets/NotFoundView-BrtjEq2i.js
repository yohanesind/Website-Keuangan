import{c as s,b as l,d as e,h as a,u as n,i as o,R as r,o as i,l as d}from"./index-Bh9dVajm.js";/**
 * @license lucide-vue-next v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=s("TriangleAlertIcon",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]),c={class:"flex items-center justify-center min-h-screen bg-slate-50 text-center px-6"},u={class:"mt-10"},f={__name:"NotFoundView",setup(x){return(p,t)=>(i(),l("main",c,[e("div",null,[a(n(m),{class:"mx-auto h-16 w-16 text-yellow-500"}),t[1]||(t[1]=e("h1",{class:"mt-4 text-4xl font-extrabold text-slate-900 tracking-tight sm:text-5xl"},"Halaman Tidak Ditemukan",-1)),t[2]||(t[2]=e("p",{class:"mt-4 text-lg text-slate-600"},"Maaf, kami tidak dapat menemukan halaman yang Anda cari.",-1)),e("div",u,[a(n(r),{to:"/",class:"bg-primary text-white font-bold text-lg px-8 py-4 rounded-full inline-block cta-button"},{default:o(()=>t[0]||(t[0]=[d(" Kembali ke Beranda ")])),_:1,__:[0]})])])]))}};export{f as default};
